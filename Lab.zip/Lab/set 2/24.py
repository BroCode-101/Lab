import matplotlib.pyplot as plt

# Data for the lines
x = [1, 2, 3, 4, 5]
y1 = [2, 4, 6, 8, 10]
y2 = [1, 3, 5, 7, 9]

# Plot the lines with markers
plt.plot(x, y1, marker='o', color='blue', label='Line 1')  # Circle markers
plt.plot(x, y2, marker='s', color='red', label='Line 2')   # Square markers

# Add title and labels
plt.title("Plot with Two Lines and Markers")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.legend()  # Show legend

# Show the plot
plt.show()


import matplotlib.pyplot as plt
import numpy as np

# Data
x = np.array([0, 1, 2, 3, 4, 5])
y1 = x ** 2
y2 = x ** 2.5
y3 = x * 2

# Plot all lines in one command
plt.plot(x, y1, 'r-o',   # red line with circle marker
         x, y2, 'g--s', # green dashed line with square marker
         x, y3, 'b:^')  # blue dotted line with triangle marker

# Add title and labels
plt.title("Multiple Lines with Different Formats")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.legend(["y = x^2", "y = x^2.5", "y = 2x"])

# Show the plot
plt.show()
