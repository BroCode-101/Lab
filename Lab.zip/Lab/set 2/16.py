import numpy as np

# Create arrays
zeros_array = np.zeros(10)   # Array of 10 zeros
ones_array = np.ones(10)     # Array of 10 ones
fives_array = np.full(10, 5) # Array of 10 fives

# Display the arrays
print("Array of 10 zeros:", zeros_array)
print("Array of 10 ones:", ones_array)
print("Array of 10 fives:", fives_array)
