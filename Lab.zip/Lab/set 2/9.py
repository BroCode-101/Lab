import matplotlib.pyplot as plt

# -----------------------------
# Part (i): Pie chart of programming language popularity
# -----------------------------
languages = ['C++', 'Python', 'PHP', 'JavaScript', 'C#', 'Java']
popularity = [24.2, 37.6, 7.7, 8, 7.7, 6.7]

plt.figure(figsize=(8, 6))
plt.pie(popularity, labels=languages, autopct='%1.1f%%', startangle=140, colors=['blue', 'green', 'orange', 'red', 'purple', 'cyan'])
plt.title("Popularity of Programming Languages")
plt.show()

# -----------------------------
# Part (ii): Scatter plot comparing marks in Political Science and Maths
# -----------------------------
# Marks of 10 students
political_science_marks = [75, 88, 92, 68, 84, 79, 95, 70, 82, 90]
maths_marks = [80, 85, 90, 65, 88, 78, 94, 72, 80, 89]

plt.figure(figsize=(8, 6))
plt.scatter(political_science_marks, maths_marks, color='magenta', marker='o')
plt.title("Scatter Plot of Political Science vs Maths Marks")
plt.xlabel("Political Science Marks")
plt.ylabel("Maths Marks")
plt.grid(True)
plt.show()
