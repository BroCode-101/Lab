# Import necessary libraries
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from scipy.stats import norm

# Step 1: Generate random data from a normal distribution
mean = 0       # Mean of the distribution
std_dev = 1    # Standard deviation
size = 1000    # Number of data points

data = np.random.normal(mean, std_dev, size)

# Step 2: Plot histogram using seaborn
sns.histplot(data, bins=30, kde=False, stat='density', color='skyblue', label='Histogram')

# Step 3: Calculate PDF values
x = np.linspace(min(data)-1, max(data)+1, 1000)  # Points on x-axis
pdf = norm.pdf(x, mean, std_dev)                 # PDF of normal distribution

# Step 4: Overlay PDF on histogram
plt.plot(x, pdf, color='red', lw=2, label='PDF')

# Step 5: Customize plot
plt.title('Normal Distribution Histogram and PDF')
plt.xlabel('Value')
plt.ylabel('Density')
plt.legend()
plt.show()
