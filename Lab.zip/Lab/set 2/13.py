# Import necessary libraries
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

# Step 1: Create sample data
np.random.seed(0)
data = pd.DataFrame({
    'X': np.random.randn(50),
    'Y': np.random.randn(50),
    'Group': np.random.choice(['A', 'B', 'C'], 50)  # Group for coloring
})

# Step 2: Plot correlation heatmap
plt.figure(figsize=(6,5))
sns.heatmap(data[['X', 'Y']].corr(), annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Correlation Heatmap')
plt.show()

# Step 3: Scatter plot with colors for groups
plt.figure(figsize=(7,5))
sns.scatterplot(data=data, x='X', y='Y', hue='Group', palette='Set1', s=100)
plt.title('Scatter Plot with Colored Groups')
plt.xlabel('X')
plt.ylabel('Y')
plt.legend(title='Group')
plt.show()
