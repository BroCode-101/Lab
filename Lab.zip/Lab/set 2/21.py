import numpy as np

# Example array of angles in radians
radians = np.array([0, np.pi/6, np.pi/4, np.pi/3, np.pi/2])

# Convert radians to degrees
degrees = np.degrees(radians)

print("Angles in radians:", radians)
print("Angles in degrees:", degrees)


# Example vectors
vector_a = np.array([1, 2, 3])
vector_b = np.array([4, 5, 6])

# Inner product (dot product)
inner_product = np.inner(vector_a, vector_b)

# Outer product
outer_product = np.outer(vector_a, vector_b)

# Cross product
cross_product = np.cross(vector_a, vector_b)

print("Vector A:", vector_a)
print("Vector B:", vector_b)
print("Inner product:", inner_product)
print("Outer product:\n", outer_product)
print("Cross product:", cross_product)
