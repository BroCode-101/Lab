import matplotlib.pyplot as plt

# Marks of 10 students
math_marks = [85, 78, 92, 70, 88, 76, 95, 89, 82, 91]
science_marks = [80, 75, 90, 65, 85, 79, 94, 87, 80, 90]

# Create scatter plot
plt.scatter(math_marks, science_marks, color='blue', marker='o')

# Add title and labels
plt.title("Scatter Plot of Mathematics vs Science Marks")
plt.xlabel("Mathematics Marks")
plt.ylabel("Science Marks")

# Show plot
plt.show()


import matplotlib.pyplot as plt
import numpy as np

# Create x values
x = np.array([0, 1, 2, 3, 4, 5])

# Create y values for different lines
y1 = x
y2 = x**2
y3 = np.sqrt(x)

# Plot all lines in one command with different format styles
plt.plot(x, y1, 'r-o',    # red line with circle marker
         x, y2, 'g--s',   # green dashed line with square marker
         x, y3, 'b:^')    # blue dotted line with triangle marker

# Add title and labels
plt.title("Multiple Lines with Different Formats")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.legend(["y = x", "y = x^2", "y = √x"])

# Show the plot
plt.show()
