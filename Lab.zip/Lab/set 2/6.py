import pandas as pd

# Dictionary data
data = {
    'Name': ['Alice', 'Bob', 'Charlie', 'David'],
    'Age': [25, 30, 35, 40],
    'City': ['New York', 'Los Angeles', 'Chicago', 'Houston']
}

# Specified index labels
index_labels = ['A', 'B', 'C', 'D']

# Create DataFrame
df = pd.DataFrame(data, index=index_labels)

# Display the DataFrame
print("DataFrame with specified index labels:")
print(df)
