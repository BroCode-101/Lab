import numpy as np

# Example square matrix
matrix = np.array([[2, 3],
                   [1, 4]])

# a) Compute the inverse of the matrix
try:
    inverse_matrix = np.linalg.inv(matrix)
    print("Inverse of the matrix:\n", inverse_matrix)
except np.linalg.LinAlgError:
    print("Matrix is singular and cannot be inverted.")

# b) Calculate the determinant of the matrix
determinant = np.linalg.det(matrix)
print("Determinant of the matrix:", determinant)
