import numpy as np

# Create a NumPy array
arr = np.array([12, 5, 7, 1, 19, 3])

# Sort the array
sorted_arr = np.sort(arr)

print("Original array:", arr)
print("Sorted array:", sorted_arr)

k = 3  # Example: 3rd smallest value

# Find Kth smallest using sorting
kth_smallest = np.sort(arr)[k-1]  # k-1 because indexing starts at 0

print(f"{k}th smallest value:", kth_smallest)

n = 2  # Example: 2nd largest value

# Find nth largest using sorting
nth_largest = np.sort(arr)[-n]  # Negative index counts from the end

print(f"{n}th largest value:", nth_largest)
