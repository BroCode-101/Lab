import numpy as np

# Define a structured data type
student_dtype = np.dtype([
    ('name', 'U20'),    # Unicode string with max length 20
    ('height', 'f4'),   # float32
    ('class', 'i4')     # int32
])

# Sample student data
students = np.array([
    ('Alice', 160.5, 10),
    ('Bob', 155.2, 9),
    ('Charlie', 170.8, 11),
    ('David', 165.3, 10)
], dtype=student_dtype)

# Sort the array by height
students_sorted = np.sort(students, order='height')

print("Students sorted by height:")
print(students_sorted)


import matplotlib.pyplot as plt

# Sample data for three groups
group_A = {'weight': [55, 60, 65], 'height': [160, 165, 170]}
group_B = {'weight': [50, 55, 60], 'height': [155, 160, 165]}
group_C = {'weight': [60, 65, 70], 'height': [170, 175, 180]}

# Create scatter plot
plt.scatter(group_A['weight'], group_A['height'], color='red', label='Group A')
plt.scatter(group_B['weight'], group_B['height'], color='blue', label='Group B')
plt.scatter(group_C['weight'], group_C['height'], color='green', label='Group C')

# Add titles and labels
plt.title("Scatter Plot of Weights vs Heights for Three Groups")
plt.xlabel("Weight (kg)")
plt.ylabel("Height (cm)")
plt.legend()

# Display plot
plt.show()
