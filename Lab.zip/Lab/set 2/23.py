import numpy as np

# Create a 5x5 array with random values between 0 and 1
array = np.random.rand(5, 5)
print("Original Array:\n", array)

# Sort each row
sorted_array = np.sort(array, axis=1)
print("\nArray with Rows Sorted:\n", sorted_array)


import matplotlib.pyplot as plt

# Sample data: years and sea level rise in mm
years = np.arange(2014, 2024)  # Last 10 years
sea_level_rise = [3.1, 3.2, 3.3, 3.5, 3.7, 3.8, 4.0, 4.2, 4.3, 4.5]  # Example values

# Create scatter plot
plt.scatter(years, sea_level_rise, color='blue')

# Add labels and title
plt.title("Sea Level Rise Over Past 10 Years")
plt.xlabel("Year")
plt.ylabel("Sea Level Rise (mm)")
plt.grid(True)

# Display the plot
plt.show()
