import matplotlib.pyplot as plt
import numpy as np

# Sample financial data (Monthly Revenue in $1000s)
months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
revenue = [50, 55, 52, 60, 65, 70, 68, 75, 80, 78, 85, 90]
expenses = [30, 35, 33, 40, 42, 45, 43, 50, 55, 53, 60, 65]

# -----------------------------
# Part 1: Line Chart
# -----------------------------
plt.figure(figsize=(10, 5))
plt.plot(months, revenue, marker='o', color='green', linewidth=2, label='Revenue')
plt.plot(months, expenses, marker='s', color='red', linewidth=2, label='Expenses')
plt.title("Line Chart: Monthly Revenue vs Expenses")
plt.xlabel("Months")
plt.ylabel("Amount ($1000s)")
plt.legend()
plt.grid(True)
plt.show()

# -----------------------------
# Part 2: Bar Chart
# -----------------------------
x = np.arange(len(months))  # the label locations
width = 0.35  # width of the bars

plt.figure(figsize=(10, 5))
plt.bar(x - width/2, revenue, width, color='green', label='Revenue')
plt.bar(x + width/2, expenses, width, color='red', label='Expenses')
plt.title("Bar Chart: Monthly Revenue vs Expenses")
plt.xlabel("Months")
plt.ylabel("Amount ($1000s)")
plt.xticks(x, months)
plt.legend()
plt.show()

# -----------------------------
# Part 3: Scatter Chart
# -----------------------------
plt.figure(figsize=(10, 5))
plt.scatter(months, revenue, color='green', s=100, label='Revenue')
plt.scatter(months, expenses, color='red', s=100, label='Expenses')
plt.title("Scatter Chart: Monthly Revenue vs Expenses")
plt.xlabel("Months")
plt.ylabel("Amount ($1000s)")
plt.legend()
plt.grid(True)
plt.show()
