import numpy as np

# =============================
# a) Initialize 2-D and 3-D arrays
# =============================
# 2-D array (2x3)
array_2d = np.array([[1, 2, 3], [4, 5, 6]])
print("2-D Array:\n", array_2d)

# 3-D array (2x2x3)
array_3d = np.array([[[1, 2, 3], [4, 5, 6]],
                     [[7, 8, 9], [10, 11, 12]]])
print("\n3-D Array:\n", array_3d)


# =============================
# b) Element-wise arithmetic operations
# =============================
array_a = np.array([1, 2, 3])
array_b = np.array([4, 5, 6])

sum_array = array_a + array_b
diff_array = array_b - array_a
prod_array = array_a * array_b
div_array = array_b / array_a

print("\nElement-wise Sum:", sum_array)
print("Element-wise Difference:", diff_array)
print("Element-wise Product:", prod_array)
print("Element-wise Division:", div_array)


# =============================
# c) Reshape and Flatten the array
# =============================
array = np.arange(12)  # Array from 0 to 11
reshaped_array = array.reshape(3, 4)  # Reshape to 3x4
flattened_array = reshaped_array.flatten()  # Flatten back to 1-D

print("\nOriginal 1-D Array:", array)
print("Reshaped Array (3x4):\n", reshaped_array)
print("Flattened Array:", flattened_array)


# =============================
# d) Fill arrays with zeros and ones
# =============================
zeros_2d = np.zeros((2, 3))
ones_3d = np.ones((2, 2, 2))

print("\n2-D Zeros Array:\n", zeros_2d)
print("3-D Ones Array:\n", ones_3d)
