# Import necessary library
import matplotlib.pyplot as plt

# Example data: Number of games played and corresponding scores
games_played = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]  # Number of games
scores_obtained = [10, 20, 15, 25, 30, 28, 35, 40, 38, 45]  # Scores in each game

# Create a scatter plot
plt.scatter(games_played, scores_obtained, color='blue', marker='o')

# Adding titles and labels
plt.title("Scatter Plot of Games Played vs Scores Obtained")
plt.xlabel("Number of Games Played")
plt.ylabel("Scores Obtained")

# Display the plot
plt.show()
