import numpy as np

# Example square matrix
matrix = np.array([[1, 2, 3],
                   [4, 5, 6],
                   [7, 8, 9]])

# Compute sum of diagonal elements
diagonal_sum = np.trace(matrix)  # trace() gives the sum of diagonal elements
print("Sum of diagonal elements:", diagonal_sum)


# Example matrices
A = np.array([[1, 2],
              [3, 4]])

B = np.array([[5, 6],
              [7, 8]])

# Compute matrix product
product = np.dot(A, B)  # or A @ B
print("Matrix product of A and B:\n", product)
