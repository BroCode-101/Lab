# Initialize an empty list to store user input
numbers = []

print("Enter integers one by one. Type 'done' to finish.")

while True:
    user_input = input("Enter an integer (or 'done' to finish): ")
    
    if user_input.lower() == 'done':
        break
    try:
        num = int(user_input)
        numbers.append(num)
    except ValueError:
        print("Invalid input! Please enter an integer.")

# Compute total and mean
if numbers:  # check if the list is not empty
    total = sum(numbers)
    mean = total / len(numbers)
    print(f"\nTotal of entered integers: {total}")
    print(f"Mean of entered integers: {mean:.2f}")
else:
    print("No integers were entered.")
