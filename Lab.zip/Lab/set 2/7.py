# Import necessary libraries
import matplotlib.pyplot as plt
import numpy as np

# -----------------------------
# Part (a): Two or more lines with legends, different widths and colors
# -----------------------------
x = np.array([0, 1, 2, 3, 4, 5])
y1 = np.array([0, 1, 4, 9, 16, 25])
y2 = np.array([0, 1, 2, 3, 4, 5])

plt.figure(figsize=(10, 5))
plt.plot(x, y1, color='blue', linewidth=2, label='y = x^2')
plt.plot(x, y2, color='red', linewidth=4, label='y = x')
plt.title("Part (a): Lines with Different Colors and Widths")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.legend()
plt.grid(True)
plt.show()

# -----------------------------
# Part (b): Two or more lines with different styles
# -----------------------------
plt.figure(figsize=(10, 5))
plt.plot(x, y1, 'b--', label='y = x^2 (dashed)')   # blue dashed line
plt.plot(x, y2, 'r-.', label='y = x (dash-dot)')   # red dash-dot line
plt.plot(x, y1-y2, 'g:', label='y = x^2 - x (dotted)') # green dotted line
plt.title("Part (b): Lines with Different Styles")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.legend()
plt.grid(True)
plt.show()

# -----------------------------
# Part (c): Vertical Bar Chart of Programming Language Popularity
# -----------------------------
languages = ['C++', 'Python', 'PHP', 'JavaScript', 'C#', 'Java']
popularity = [24.2, 37.6, 7.7, 8, 7.7, 6.7]

plt.figure(figsize=(10, 5))
plt.bar(languages, popularity, color=['blue', 'green', 'orange', 'red', 'purple', 'cyan'])
plt.title("Part (c): Popularity of Programming Languages")
plt.xlabel("Programming Languages")
plt.ylabel("Popularity (%)")
plt.show()
