# List of marks scored by students
marks = [
    90, 95, 96, 89, 78,
    88, 78, 56, 88, 98,
    66, 77, 98, 45, 56,
    89, 98, 76, 54, 77
]

# Step 1: Sort the marks
sorted_marks = sorted(marks)

# Step 2: Get unique marks for class intervals (less than type)
unique_marks = sorted(set(sorted_marks))

# Step 3: Calculate less-than cumulative frequency
cumulative_frequency = []
for mark in unique_marks:
    count = sum(m < mark for m in marks)  # count of marks less than the current mark
    cumulative_frequency.append(count)

# Step 4: Display results
print("Marks (Less than type)\tCumulative Frequency")
for mark, freq in zip(unique_marks, cumulative_frequency):
    print(f"{mark}\t\t\t{freq}")
