import numpy as np
from itertools import combinations

# Create an array
arr = np.array([1, 2, 3])

# Generate all possible combinations of different lengths
all_combinations = []
for r in range(1, len(arr)+1):
    comb = list(combinations(arr, r))
    all_combinations.extend(comb)

# Convert to NumPy array if desired
all_combinations_np = np.array(all_combinations, dtype=object)

print("All possible combinations:")
print(all_combinations_np)


import numpy as np

# Create an 8x8 matrix
checkerboard = np.zeros((8, 8), dtype=int)

# Fill the checkerboard pattern
checkerboard[1::2, ::2] = 1
checkerboard[::2, 1::2] = 1

print("8x8 Checkerboard pattern:")
print(checkerboard)
