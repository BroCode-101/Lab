import numpy as np

# =============================
# Sample arrays for demonstration
# =============================
# For part (a)
array_with_zeros = np.array([[1, 2, 0],
                             [4, 5, 6],
                             [0, 8, 9]])
print("Original Array:\n", array_with_zeros)

# =============================
# a) Remove rows that contain zero
# =============================
array_no_zeros = array_with_zeros[~np.any(array_with_zeros == 0, axis=1)]
print("\nArray after removing rows with zero:\n", array_no_zeros)


# =============================
# b) Multiplication of two matrices
# =============================
matrix1 = np.array([[1, 2], [3, 4]])
matrix2 = np.array([[5, 6], [7, 8]])

matrix_product = np.dot(matrix1, matrix2)
print("\nMatrix Multiplication Result:\n", matrix_product)


# =============================
# c) Compute inverse of a given matrix
# =============================
matrix = np.array([[2, 1], [5, 3]])
matrix_inverse = np.linalg.inv(matrix)
print("\nInverse of the matrix:\n", matrix_inverse)


# =============================
# d) Compute eigenvalues and eigenvectors
# =============================
square_matrix = np.array([[2, 0], [0, 3]])
eigenvalues, eigenvectors = np.linalg.eig(square_matrix)
print("\nEigenvalues:", eigenvalues)
print("Eigenvectors:\n", eigenvectors)


# =============================
# e) Compute determinant
# =============================
determinant = np.linalg.det(square_matrix)
print("\nDeterminant of the matrix:", determinant)


# =============================
# f) Mean, Standard Deviation, Variance along rows
# =============================
array_stats = np.array([[1, 2, 3], [4, 5, 6]])
mean_row = np.mean(array_stats, axis=1)
std_row = np.std(array_stats, axis=1)
var_row = np.var(array_stats, axis=1)

print("\nMean of each row:", mean_row)
print("Standard Deviation of each row:", std_row)
print("Variance of each row:", var_row)
