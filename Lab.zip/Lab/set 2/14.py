# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# Step 1: Generate sample data for n observations
np.random.seed(0)
n = 50  # Number of observations

# Independent variable (X) and dependent variable (Y)
X = 2 * np.random.rand(n, 1)           # Random values for X
Y = 4 + 3 * X + np.random.randn(n, 1)  # Y = 4 + 3X + noise

# Step 2: Create and fit the Linear Regression model
model = LinearRegression()
model.fit(X, Y)

# Step 3: Make predictions
Y_pred = model.predict(X)

# Step 4: Print the coefficients
print("Slope (Coefficient):", model.coef_[0][0])
print("Intercept:", model.intercept_[0])

# Step 5: Plot the results
plt.scatter(X, Y, color='blue', label='Data points')
plt.plot(X, Y_pred, color='red', linewidth=2, label='Regression line')
plt.title('Linear Regression for n Observations')
plt.xlabel('X')
plt.ylabel('Y')
plt.legend()
plt.show()
