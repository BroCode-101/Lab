# Import necessary libraries
import pandas as pd
import matplotlib.pyplot as plt

# Read data from CSV file
data = pd.read_csv('medal.csv')

# Extract data for pie chart
countries = data['Country']
gold_medals = data['Gold_medal']

# Create a pie chart
plt.figure(figsize=(8, 8))
plt.pie(gold_medals, labels=countries, autopct='%1.1f%%', startangle=140, colors=['gold', 'silver', 'red', 'blue', 'green'])

# Add a title
plt.title("Gold Medal Achievements of Top 5 Countries in Olympics")

# Display the pie chart
plt.show()
