import numpy as np

# Create two arrays
arr1 = np.array([1, 2, 3, 4, 5])
arr2 = np.array([4, 5, 6, 7, 8])

# Element-wise comparison
equal_elements = arr1 == arr2
greater_elements = arr1 > arr2
less_elements = arr1 < arr2

print("Element-wise equality:", equal_elements)
print("Element-wise greater:", greater_elements)
print("Element-wise less:", less_elements)

# Set operations
union = np.union1d(arr1, arr2)
intersection = np.intersect1d(arr1, arr2)
difference = np.setdiff1d(arr1, arr2)

print("Union:", union)
print("Intersection:", intersection)
print("Difference (arr1 - arr2):", difference)


# Centigrade values stored in a NumPy array
centigrade = np.array([0, 20, 37, 100])

# Convert to Fahrenheit
fahrenheit = (centigrade * 9/5) + 32

print("Centigrade:", centigrade)
print("Fahrenheit:", fahrenheit)
