import matplotlib.pyplot as plt
import csv

# Initialize lists to store data
x_values = []
y_values = []

# Read data from the text file
with open('data.txt', 'r') as file:
    reader = csv.DictReader(file)  # reads header and maps columns
    for row in reader:
        x_values.append(float(row['x']))
        y_values.append(float(row['y']))

# Plot the line
plt.figure(figsize=(8, 5))
plt.plot(x_values, y_values, marker='o', color='blue', linewidth=2)

# Add labels and title
plt.xlabel('X-axis Label')
plt.ylabel('Y-axis Label')
plt.title('Line Plot from Text File')

# Display the grid
plt.grid(True)

# Show the plot
plt.show()
