# Import required libraries
import matplotlib.pyplot as plt
import numpy as np

# Generate data
x = np.linspace(0, 10, 100)
y1 = np.sin(x)
y2 = np.cos(x)
y3 = np.tan(x) / 5  # scaled down for visibility

# -----------------------------------------------------------
# (a) Multiple types of charts on a single set of axes
# -----------------------------------------------------------
plt.figure(figsize=(8, 5))
plt.plot(x, y1, label='Sine Wave', color='b')         # Line plot
plt.scatter(x, y2, label='Cosine Points', color='r')   # Scatter plot
plt.bar(x[::10], y3[::10], width=0.3, label='Tangent Bars', color='g')  # Bar plot

plt.title("Multiple Chart Types on One Set of Axes")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.legend()
plt.grid(True)
plt.show()

# -----------------------------------------------------------
# (b) Two or more lines with legends, different widths and colors
# -----------------------------------------------------------
plt.figure(figsize=(8, 5))
plt.plot(x, y1, color='magenta', linewidth=2, label='Sine (Width=2)')
plt.plot(x, y2, color='orange', linewidth=4, label='Cosine (Width=4)')
plt.title("Lines with Different Colors and Widths")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.legend()
plt.grid(True)
plt.show()

# -----------------------------------------------------------
# (c) Two or more lines with different styles
# -----------------------------------------------------------
plt.figure(figsize=(8, 5))
plt.plot(x, y1, linestyle='-', color='blue', label='Solid Line')
plt.plot(x, y2, linestyle='--', color='green', label='Dashed Line')
plt.plot(x, y3, linestyle=':', color='red', label='Dotted Line')
plt.title("Lines with Different Styles")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.legend()
plt.grid(True)
plt.show()
