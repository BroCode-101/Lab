import numpy as np

# Create a 4x4 array with random values between 0 and 1
array = np.random.rand(4, 4)
print("Original 4x4 Array:\n", array)

# a) Sum of each row
row_sums = np.sum(array, axis=1)
print("\nSum of each row:", row_sums)

# b) Second-largest value in each row
# Sort each row in descending order and pick the second element
second_largest = np.sort(array, axis=1)[:, -2]
print("\nSecond-largest value in each row:", second_largest)
