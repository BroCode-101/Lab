# -----------------------------------------------------------
# (a) Find sum and average of n integer numbers
# -----------------------------------------------------------

# Input: number of elements
n = int(input("Enter how many numbers: "))

# Read numbers from user
numbers = []
for i in range(n):
    num = int(input(f"Enter number {i+1}: "))
    numbers.append(num)

# Calculate sum and average
total_sum = sum(numbers)
average = total_sum / n

print("\n--- Sum and Average ---")
print("Numbers:", numbers)
print("Sum:", total_sum)
print("Average:", average)

# -----------------------------------------------------------
# (b) Find variance and standard deviation of the same set
# -----------------------------------------------------------

# Compute mean
mean = average

# Compute variance: (Σ (xi - mean)²) / n
variance = sum((x - mean) ** 2 for x in numbers) / n

# Compute standard deviation: √variance
std_dev = variance ** 0.5

print("\n--- Variance and Standard Deviation ---")
print("Variance:", variance)
print("Standard Deviation:", std_dev)
