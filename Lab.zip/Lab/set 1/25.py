import numpy as np

# Create a 4x4 array with random values between 0 and 10
array = np.random.rand(4, 4) * 10
print("Original 4x4 Array:\n", array)

# a) Determine the sum of each row
row_sums = np.sum(array, axis=1)
print("\nSum of each row:", row_sums)

# b) Subtract the mean of each row from each element
row_means = np.mean(array, axis=1, keepdims=True)
adjusted_array = array - row_means
print("\nArray after subtracting row mean from each element:\n", adjusted_array)
