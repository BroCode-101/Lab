# Import necessary libraries
import matplotlib.pyplot as plt

# ----------------------------------------
# Step 1: Data for years and populations
# ----------------------------------------
years = [2015, 2016, 2017, 2018, 2019, 2020]
population = [12, 20, 26, 30, 32, 36]

# ----------------------------------------
# Step 2: Create a line chart
# ----------------------------------------
plt.figure(figsize=(8, 5))  # Set figure size

plt.plot(years, population, 
         color='darkorange', 
         marker='o', 
         linestyle='-', 
         linewidth=2, 
         markersize=8, 
         label='White Tiger Population')

# ----------------------------------------
# Step 3: Add titles and labels
# ----------------------------------------
plt.title("Population Growth of White Tigers (2015–2020)", fontsize=14)
plt.xlabel("Year", fontsize=12)
plt.ylabel("Number of White Tigers", fontsize=12)

# Add grid and legend
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend()

# ----------------------------------------
# Step 4: Display the plot
# ----------------------------------------
plt.tight_layout()
plt.show()
