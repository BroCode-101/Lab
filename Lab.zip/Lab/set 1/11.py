import numpy as np

# -----------------------------------------------------------
# (a) Create a random array and compute average, variance, std deviation
# -----------------------------------------------------------

# Create a random array of 10 elements (values between 0 and 100)
arr = np.random.randint(0, 100, 10)
print("Random Array:", arr)

# Compute statistics
average = np.mean(arr)
variance = np.var(arr)
std_dev = np.std(arr)

print("\n--- Statistics ---")
print("Average (Mean):", average)
print("Variance:", variance)
print("Standard Deviation:", std_dev)

# -----------------------------------------------------------
# (b) Get floor, ceiling, and truncated values of an array
# -----------------------------------------------------------

# Create an array with decimal values
arr2 = np.array([1.2, 3.7, -2.8, 4.5, -1.1])
print("\nOriginal Array:", arr2)

# Apply NumPy functions
floor_values = np.floor(arr2)
ceil_values = np.ceil(arr2)
trunc_values = np.trunc(arr2)

print("\n--- Rounding Operations ---")
print("Floor Values:", floor_values)
print("Ceiling Values:", ceil_values)
print("Truncated Values:", trunc_values)
