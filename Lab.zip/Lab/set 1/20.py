import numpy as np

# Example array
arr = np.array([7, 2, 1, 6, 8, 5, 3, 4])

# Partition the array at index 3
partitioned_arr = np.partition(arr, 3)

print("Original array:", arr)
print("Partitioned array:", partitioned_arr)


import numpy as np

# Example 2D array
arr_2d = np.array([
    [3, 2, 5],
    [1, 4, 2],
    [2, 3, 4]
])

# Sort by 2nd column (index 1)
n = 1
sorted_arr = arr_2d[arr_2d[:, n].argsort()]

print("Original array:\n", arr_2d)
print(f"Array sorted by column {n}:\n", sorted_arr)
