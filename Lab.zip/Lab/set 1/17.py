import numpy as np

# Define data for students
student_data = [
    ('Alice', 5.4, '10A'),
    ('Bob', 5.9, '10B'),
    ('Charlie', 5.7, '10A')
]

# Define the data types for each field
dtype = [('name', 'U10'), ('height', 'f4'), ('class', 'U5')]

# Create the structured array
students = np.array(student_data, dtype=dtype)

# Display the structured array
print("Structured Array:")
print(students)

# Accessing individual fields
print("\nNames:", students['name'])
print("Heights:", students['height'])
print("Classes:", students['class'])

import numpy as np

# Example array
arr = np.array([40, 10, 30, 20])

# Get indices that would sort the array
sorted_indices = np.argsort(arr)

print("Original array:", arr)
print("Indices of sorted elements:", sorted_indices)
print("Sorted array using indices:", arr[sorted_indices])
