# Import required libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# ------------------------------------------
# Step 1: Generate Sample Data
# ------------------------------------------
np.random.seed(42)
n = 100

# Create synthetic data
x = np.random.rand(n) * 10               # Independent variable
y = 2.5 * x + np.random.randn(n) * 3     # Dependent variable (correlated with x)
z = np.random.rand(n) * 10               # Unrelated variable

# Create a DataFrame
data = pd.DataFrame({
    'X': x,
    'Y': y,
    'Z': z
})

# ------------------------------------------
# Step 2: Compute Correlation Matrix
# ------------------------------------------
corr_matrix = data.corr()
print("Correlation Matrix:\n", corr_matrix)

# ------------------------------------------
# Step 3: Visualize Correlation Matrix (Heatmap)
# ------------------------------------------
plt.figure(figsize=(6, 4))
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Correlation Matrix Heatmap')
plt.show()

# ------------------------------------------
# Step 4: Scatter Plots
# ------------------------------------------
# Simple scatter plot between X and Y
plt.figure(figsize=(6, 4))
plt.scatter(data['X'], data['Y'], color='teal', alpha=0.7)
plt.title('Scatter Plot: X vs Y')
plt.xlabel('X')
plt.ylabel('Y')
plt.grid(True)
plt.show()

# Pairwise scatter plot for all variables
sns.pairplot(data)
plt.suptitle('Pairwise Scatter Plots', y=1.02)
plt.show()
