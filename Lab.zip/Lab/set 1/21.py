import numpy as np

# Example array
arr = np.array([1, 2, 2, 3, 4, 2, 5, 3, 3, 3])

# Find unique values and their counts
values, counts = np.unique(arr, return_counts=True)

# Most frequent value
most_frequent = values[np.argmax(counts)]

print("Array:", arr)
print("Most frequent value:", most_frequent)


import numpy as np

# Generate random 10x2 matrix (Cartesian coordinates)
cartesian = np.random.rand(10, 2) * 10  # random values between 0 and 10

# Split into x and y
x = cartesian[:, 0]
y = cartesian[:, 1]

# Convert to polar coordinates
r = np.sqrt(x**2 + y**2)
theta = np.arctan2(y, x)  # angle in radians

polar = np.column_stack((r, theta))

print("Cartesian coordinates:\n", cartesian)
print("\nPolar coordinates (r, θ in radians):\n", polar)
