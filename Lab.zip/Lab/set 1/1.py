import numpy as np

# a) Initialize 1-D and 2-D arrays
arr_1d = np.array([1, 2, 3])
arr_2d = np.array([[4, 5, 6], [7, 8, 9]])

# b) Perform Dot matrix operation
# Dot product between 1-D and reshaped 2-D array
arr_1d_reshaped = arr_1d.reshape(3, 1)
dot_result = np.dot(arr_2d, arr_1d_reshaped)

# c) Reshape and Flatten the array
reshaped = arr_2d.reshape(3, 2)
flattened = arr_2d.flatten()

# d) Fill arrays with value 7 and 8
filled_7 = np.full((2, 3), 7)
filled_8 = np.full((3, 2), 8)


print("1-D Array:\n", arr_1d)
print("2-D Array:\n", arr_2d)
print("Dot Product Result:\n", dot_result)
print("Reshaped Array (3x2):\n", reshaped)
print("Flattened Array:\n", flattened)
print("Array filled with 7:\n", filled_7)
print("Array filled with 8:\n", filled_8)