import numpy as np

# Logistic (sigmoid) function
def sigmoid(z):
    return 1 / (1 + np.exp(-z))

# Logistic regression training function
def logistic_regression(X, y, lr=0.01, epochs=1000):
    """
    X: Feature matrix (n x m)
    y: Target vector (n x 1)
    lr: Learning rate
    epochs: Number of iterations
    """
    n, m = X.shape
    weights = np.zeros((m, 1))
    bias = 0

    for i in range(epochs):
        # Linear model
        z = np.dot(X, weights) + bias

        # Prediction using sigmoid
        y_pred = sigmoid(z)

        # Compute loss (binary cross-entropy)
        loss = -(1/n) * np.sum(y * np.log(y_pred + 1e-9) + (1 - y) * np.log(1 - y_pred + 1e-9))

        # Gradient computation
        dw = (1/n) * np.dot(X.T, (y_pred - y))
        db = (1/n) * np.sum(y_pred - y)

        # Parameter update
        weights -= lr * dw
        bias -= lr * db

        # Print progress every 100 iterations
        if i % 100 == 0:
            print(f"Epoch {i}: Loss = {loss:.4f}")

    return weights, bias

# Prediction function
def predict(X, weights, bias):
    probs = sigmoid(np.dot(X, weights) + bias)
    return [1 if p > 0.5 else 0 for p in probs]

# -------------------------------
# Example usage
# -------------------------------

# Example: n observations with 2 features
np.random.seed(0)
n = 100
X = np.random.rand(n, 2)
y = (X[:, 0] + X[:, 1] > 1).astype(int).reshape(n, 1)  # Create a simple binary target

# Train the model
weights, bias = logistic_regression(X, y, lr=0.5, epochs=1000)

# Make predictions
preds = predict(X, weights, bias)

# Calculate accuracy
accuracy = np.mean(preds == y.flatten()) * 100
print(f"\nModel Accuracy: {accuracy:.2f}%")
