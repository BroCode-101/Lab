import matplotlib.pyplot as plt

# -----------------------------------------------------------
# (a) Pie chart - Hours spent by a kid on different activities
# -----------------------------------------------------------

# Data
activities = ['Sleep', 'School', 'Home', 'Play', 'Others']
hours = [8, 7, 4, 2, 3]

# Create Pie Chart
plt.figure(figsize=(6,6))
plt.pie(hours,
        labels=activities,
        autopct='%1.1f%%',        # show percentages
        startangle=90,            # rotate start angle
        colors=['#66b3ff','#99ff99','#ffcc99','#ff9999','#c2c2f0'],
        shadow=True)

plt.title("Daily Activities of a Kid (Hours Spent)")
plt.show()

# -----------------------------------------------------------
# (b) Scatter plot - Comparing marks of Mathematics and Science
# -----------------------------------------------------------

# Data for 10 students
students = list(range(1, 11))
math_marks = [78, 85, 92, 88, 76, 95, 89, 67, 80, 90]
science_marks = [82, 79, 88, 91, 74, 93, 85, 70, 83, 87]

# Create Scatter Plot
plt.figure(figsize=(7,5))
plt.scatter(math_marks, science_marks, color='purple', s=80, marker='o')

# Label axes and title
plt.title("Comparison of Mathematics and Science Marks")
plt.xlabel("Mathematics Marks")
plt.ylabel("Science Marks")

# Optionally add grid
plt.grid(True, linestyle='--', alpha=0.6)

plt.show()
