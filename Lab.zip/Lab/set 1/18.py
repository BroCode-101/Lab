import matplotlib.pyplot as plt

# Data
years = [2020, 2021, 2022, 2023, 2024]
cars_manufactured = [16000, 25000, 30000, 32000, 35000]

# ------------------------
# 1. Bar Chart
# ------------------------
plt.figure(figsize=(8,5))
plt.bar(years, cars_manufactured, color='skyblue')
plt.title("Number of Cars Manufactured per Year")
plt.xlabel("Year")
plt.ylabel("Number of Cars")
plt.xticks(years)
plt.show()

# ------------------------
# 2. Pie Chart
# ------------------------
plt.figure(figsize=(7,7))
plt.pie(cars_manufactured, labels=years, autopct='%1.1f%%', startangle=140, colors=['#ff9999','#66b3ff','#99ff99','#ffcc99','#c2c2f0'])
plt.title("Proportion of Cars Manufactured by Year")
plt.show()
