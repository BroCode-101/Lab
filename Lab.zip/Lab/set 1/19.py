import numpy as np

# Example array
arr = np.array([40, 10, 30, 20])

# Get indices of the sorted elements
sorted_indices = np.argsort(arr)

print("Original array:", arr)
print("Indices of sorted elements:", sorted_indices)
print("Sorted array using indices:", arr[sorted_indices])


import numpy as np

# Example complex array
complex_arr = np.array([3+4j, 1+2j, 2+1j, 3+1j, 1+1j])

# Sort by real part first, then imaginary part
sorted_complex = np.array(sorted(complex_arr, key=lambda x: (x.real, x.imag)))

print("Original complex array:", complex_arr)
print("Sorted complex array (by real then imaginary):", sorted_complex)
