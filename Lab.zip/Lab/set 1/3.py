import numpy as np
import itertools

# Create a 2D array
arr_2d = np.array([[1, 2], [3, 4]])

# Generate all possible combinations of elements (Cartesian product)
flat = arr_2d.flatten()
combinations = list(itertools.product(flat, repeat=2))

print("2D Array:\n", arr_2d)
print("All possible 2-element combinations:\n", combinations)

# Create an 8x8 checkerboard matrix using NumPy
checkerboard = np.zeros((8, 8), dtype=int)
checkerboard[1::2, ::2] = 1
checkerboard[::2, 1::2] = 1

print("8x8 Checkerboard Pattern:\n", checkerboard)