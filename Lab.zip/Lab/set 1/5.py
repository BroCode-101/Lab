import numpy as np

# Define two arrays
a = np.array([1, 2, 3, 4])
b = np.array([1, 2, 3, 5])

# Overall equality
equal = np.array_equal(a, b)
print("Arrays Equal:", equal)

# Set operations
print("Union:", np.union1d(a, b))
print("Intersection:", np.intersect1d(a, b))
print("Set Difference (a - b):", np.setdiff1d(a, b))
print("Symmetric Difference:", np.setxor1d(a, b))


import numpy as np

# Fahrenheit array
fahrenheit = np.array([32, 68, 100, 212])

# Convert to Centigrade
centigrade = (fahrenheit - 32) * 5 / 9

print("Centigrade:", centigrade)