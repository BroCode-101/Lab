import pandas as pd

# Runs scored by Virat Kohli in last T20 matches
runs = [45, 34, 50, 75, 22,
        56, 63, 70, 49, 33,
        8, 14, 39, 86, 52,
        92, 88, 70, 56, 50,
        57, 45, 42, 12, 39]

# Define class intervals (width 10)
classes = [(0, 20), (20, 40), (40, 60), (60, 80), (80, 100)]

# Calculate frequencies
freq = []
for lower, upper in classes:
    count = sum(lower < x <= upper for x in runs)
    freq.append(count)

# Calculate cumulative frequencies
cum_freq = []
total = 0
for f in freq:
    total += f
    cum_freq.append(total)

# Create DataFrame for tabular display
data = {
    "Class Interval": ["<20", "<40", "<60", "<80", "<100"],
    "Cumulative Frequency": cum_freq
}

df = pd.DataFrame(data)
print(df)
