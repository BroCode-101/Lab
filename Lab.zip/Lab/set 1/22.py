import numpy as np

# Example array
arr = np.array([10, 20, 30, 40, 50])

# Given scalar
scalar = 28

# Find the closest value
closest_value = arr[np.argmin(np.abs(arr - scalar))]

print("Array:", arr)
print("Scalar:", scalar)
print("Closest value in array:", closest_value)


import numpy as np

# Example array
arr = np.array([10, 20, 30, 40, 50])

# n-th largest value
n = 2  # 2nd largest
nth_largest = np.sort(arr)[-n]

print("Array:", arr)
print(f"{n}-th largest value:", nth_largest)
