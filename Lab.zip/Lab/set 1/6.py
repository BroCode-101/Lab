import pandas as pd

# Sample DataFrame
data = {
    'Name': ['Alice', 'Bob', 'Charlie', 'David', 'Eva'],
    'Age': [25, 30, 35, 40, 45],
    'City': ['NY', 'LA', 'Chicago', 'Houston', 'Phoenix']
}

df = pd.DataFrame(data)

# Get first 3 rows
first_three = df.head(3)

print(first_three)