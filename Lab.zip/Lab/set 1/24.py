import numpy as np

# Create a 5x5 array with random values between 0 and 100
array = np.random.randint(0, 100, size=(5, 5))
print("Original 5x5 Array:\n", array)

# a) Replace the maximum value with 0
max_index = np.unravel_index(np.argmax(array), array.shape)
array[max_index] = 0
print("\nArray after replacing maximum with 0:\n", array)

# b) Replace the minimum value with -1
min_index = np.unravel_index(np.argmin(array), array.shape)
array[min_index] = -1
print("\nArray after replacing minimum with -1:\n", array)
