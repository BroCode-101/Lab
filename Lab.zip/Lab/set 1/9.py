import matplotlib.pyplot as plt
import numpy as np

# Sample data
groups = ['G1', 'G2', 'G3', 'G4', 'G5']
means_men = [22, 30, 35, 35, 26]
means_women = [25, 32, 30, 35, 29]

# Set up positions for bars on X-axis
x = np.arange(len(groups))  # label locations
bar_width = 0.35  # width of the bars

# Create bar plot
plt.figure(figsize=(8, 5))
bars1 = plt.bar(x - bar_width/2, means_men, bar_width, label='Men', color='blue')
bars2 = plt.bar(x + bar_width/2, means_women, bar_width, label='Women', color='pink')

# Add labels, title, and legend
plt.xlabel('Group')
plt.ylabel('Scores')
plt.title('Scores by Group and Gender')
plt.xticks(x, groups)
plt.legend()

# Optionally add grid lines for better readability
plt.grid(axis='y', linestyle='--', alpha=0.7)

# Display the plot
plt.show()
