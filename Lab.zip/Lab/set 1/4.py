import numpy as np

# Original 2D array
arr = np.array([[1, 2], [3, 4]])

# Add border of zeroes
bordered = np.pad(arr, pad_width=1, mode='constant', constant_values=0)

print("Original Array:\n", arr)
print("Bordered Array:\n", bordered)


arr = np.array([1, 3, 2, 1, 4, 1, 3])

# Find most frequent value
most_freq = np.bincount(arr).argmax()

print("Most Frequent Value:", most_freq)


arr = np.array([0, 1, 0, 2, 3, 0, 4])

# Count non-zero values
count = np.count_nonzero(arr)

print("Non-Zero Count:", count)


arr = np.array([1, 2, 3, 4, 5])

# Reverse array
reversed_arr = arr[::-1]

print("Reversed Array:", reversed_arr)