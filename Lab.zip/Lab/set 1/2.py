import numpy as np

# a) Remove rows in NumPy array that contain non-numeric values
mixed_array = np.array([[1, 2, 3],
                        [4, 'a', 6],
                        [7, 8, 9]], dtype=object)

# Filter only rows with all numeric values
numeric_rows = np.array([row for row in mixed_array if all(isinstance(x, (int, float, np.number)) for x in row)], dtype=float)

# b) Compute inverse of a given matrix
matrix = np.array([[2, 1], [5, 3]])
inverse_matrix = np.linalg.inv(matrix)

# c) Compute eigenvalues and eigenvectors of a square array
square_array = np.array([[4, -2], [1, 1]])
eigen_values, eigen_vectors = np.linalg.eig(square_array)

# d) Compute mean, std deviation, and variance for each row
data_array = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
row_mean = np.mean(data_array, axis=1)
row_std = np.std(data_array, axis=1)
row_var = np.var(data_array, axis=1)

# Display results
print("Filtered Numeric Rows:\n", numeric_rows)
print("Inverse Matrix:\n", inverse_matrix)
print("Eigenvalues:\n", eigen_values)
print("Eigenvectors:\n", eigen_vectors)
print("Row-wise Mean:\n", row_mean)
print("Row-wise Std Dev:\n", row_std)
print("Row-wise Variance:\n", row_var)