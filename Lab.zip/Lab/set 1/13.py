import numpy as np
import matplotlib.pyplot as plt

# Parameters for the normal distribution
mu = 0       # Mean
sigma = 1    # Standard deviation
sample_size = 1000

# Generate random samples from a normal distribution
data = np.random.normal(mu, sigma, sample_size)

# Create histogram of the data
count, bins, ignored = plt.hist(data, bins=30, density=True, alpha=0.6, color='skyblue', edgecolor='black')

# Calculate the PDF for the normal distribution
pdf = (1 / (sigma * np.sqrt(2 * np.pi))) * np.exp(-0.5 * ((bins - mu) / sigma) ** 2)

# Plot the PDF curve
plt.plot(bins, pdf, color='red', linewidth=2, label='Normal PDF')

# Add labels and title
plt.title('Normal Distribution - Histogram & PDF')
plt.xlabel('Value')
plt.ylabel('Probability Density')
plt.legend()

# Show the plot
plt.show()
