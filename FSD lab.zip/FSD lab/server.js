const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
mongoose.connect("mongodb://127.0.0.1:27017/bugdb");
const Bug = mongoose.model("Bug", new mongoose.Schema({
  title: String,
  description: String,
  status: { type: String, default: "open" }
}));
app.get("/", async (req, res) => {
  const bugs = await Bug.find();
  let html = `
<h1>Bug Tracker</h1>
<form method="POST" action="/add">
<input name="title" placeholder="Title" required><br>
<textarea name="description" placeholder="Description"></textarea><br>
<button type="submit">Add Bug</button>
</form>
<h2>Bug List</h2>
`;

  bugs.forEach(b => {
    html += `
<p>
<b>${b.title}</b> - ${b.status}<br>
${b.description}<br>
<form method="POST" action="/toggle/${b._id}" style="display:inline;">
<button type="submit">Toggle</button>
</form>
<form method="POST" action="/delete/${b._id}" style="display:inline;">
<button type="submit">Delete</button>
</form>
</p>
`;
  });
  res.send(html);
});
app.post("/add", async (req, res) => {
  await Bug.create(req.body);
  res.redirect("/");
});
app.post("/toggle/:id", async (req, res) => {
  const bug = await Bug.findById(req.params.id);
  bug.status = bug.status === "open" ? "closed" : "open";
  await bug.save();
  res.redirect("/");
});
app.post("/delete/:id", async (req, res) => {
  await Bug.findByIdAndDelete(req.params.id);
  res.redirect("/");
});
app.listen(3000, () => console.log("Running on http://localhost:3000"));
